package Password;

import javax.swing.JPasswordField;

public class PasswordTest {
	private String userName;
	private JPasswordField password;
	public PasswordTest(String userName, JPasswordField password) {
		super();
		this.userName = userName;
		this.password = password;
	}
	
}
