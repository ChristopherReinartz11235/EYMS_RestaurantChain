package EYMS;

import javax.swing.JPasswordField;

public class Manager extends User {

	public Manager(String userName, String firstName, String lastName, JPasswordField password) {
		super(userName, firstName, lastName, password);
		// TODO Auto-generated constructor stub
	}
	void setMeal(){
		
	}
	void setMeal(Meal meal){
		
	}
}
