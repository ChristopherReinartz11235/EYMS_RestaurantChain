package EYMS;

import java.util.ArrayList;
import java.util.Map;
import javax.swing.JPasswordField;

public class Client extends User {
	private Map<String, String> contactInfo;
	private ArrayList<Meal> favouriteMeals;
	private Promotion promotion;
	private FidelityCard card; 
	
	public class Promotion {
		private boolean receiveGeneralized;
		private boolean receivePeronalized;
		private String wayOfContacting;
	}
	
	public Client(String userName, String firstName, String lastName, JPasswordField password) {
		super(userName, firstName, lastName, password);
		// TODO Auto-generated constructor stub
	}

}
