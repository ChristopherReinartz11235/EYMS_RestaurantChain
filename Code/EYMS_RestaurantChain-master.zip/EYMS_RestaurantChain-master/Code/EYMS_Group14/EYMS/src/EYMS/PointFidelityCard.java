package EYMS;

public class PointFidelityCard implements FidelityCard{

	@Override
	public boolean hasAccess() {
		// TODO Auto-generated method stub
		return false;
	}
	
	

}
