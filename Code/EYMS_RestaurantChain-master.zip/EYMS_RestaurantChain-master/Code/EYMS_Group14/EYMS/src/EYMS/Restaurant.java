package EYMS;

public class Restaurant {
	
}
