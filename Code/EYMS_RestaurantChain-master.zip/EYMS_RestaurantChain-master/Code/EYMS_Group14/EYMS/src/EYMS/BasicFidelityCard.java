package EYMS;

public class BasicFidelityCard implements FidelityCard{

	@Override
	public boolean hasAccess() {
		// TODO Auto-generated method stub
		return true;
	}

}
