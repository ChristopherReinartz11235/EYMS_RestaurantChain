package EYMS;

public class MealFactory {
	public Meal createMeal(){
		return new Meal();
	}
}
