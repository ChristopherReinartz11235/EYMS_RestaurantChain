package EYMS;

public interface FidelityCard {
	public boolean hasAccess();
}
