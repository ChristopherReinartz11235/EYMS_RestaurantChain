/**
 * 
 */
package EYMS;

/**
 * @author Christopher
 *
 */
public class LotteryFidelityCard implements FidelityCard {

	/* (non-Javadoc)
	 * @see EYMS.FidelityCard#giveAcess()
	 */
	@Override
	public boolean hasAccess() {
		// TODO Auto-generated method stub
		return false;
	}

}
